/*
 * 
 */
package Cuentas;
// TODO: Auto-generated Javadoc

/**
 * La Clase CCuenta.
 */
public class CCuenta {


    /** El atributo nombre. El nombre del cliente */
    private String nombre;
    
    /** El atributo cuenta. El número de cuenta*/
    private String cuenta;
    
    /** El atributo saldo. El dinero del que dispone en la cuenta*/
    private double saldo;
    
    /** El atributo interés. El interés que se aplica al saldo*/
    private double tipoInterés;

    /**
     * Instantiates a new c cuenta.
     */
    public CCuenta()
    {
    }

    /**
     * Instantiates a new c cuenta.
     *
     * @param nom the nom
     * @param cue the cue
     * @param sal the sal
     * @param tipo the tipo
     */
    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        setNombre(nom);
        setCuenta(cue);
        setSaldo(sal);
    }

    /**
     * Estado. Al pedir el estado nos devolverá el saldo que quede en la cuenta.
     *
     * @return the double
     */
    public double estado()
    {
        return getSaldo();
    }

    /**
     * Ingresar.	Si se quiere ingresarr una cantidad negativa te contstará: "No se puede ingresar una cantidad negativa"
     *
     * @param cantidad the cantidad
     * @throws Exception the exception
     */
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        setSaldo(getSaldo() + cantidad);
    }

    /**
     * Retirar.
     * 
     * 	Si se quiere sacar una cantidad negativa te contestará: "No se puede retirar una cantidad negativa"
     * 	Si se quiere sacar más de lo que hay en cuenta te contestará: "No hay suficiente saldo"
     *						Corregí en este texto un "se" que sobraba.
     *
     * @param cantidad the cantidad
     * @throws Exception the exception
     */
    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No hay suficiente saldo");
        setSaldo(getSaldo() - cantidad);
    }

	/**
	 * Gets the nombre. El "getter" en definitiva
	 *
	 * @return the nombre
	 */
	private String getNombre() {
		return nombre;
	}

	/**
	 * Sets the nombre. El "setter" en definitiva
	 *
	 * @param nombre the new nombre
	 */
	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Gets the cuenta. Segundo ejemplo de "getter"
	 *
	 * @return the cuenta
	 */
	private String getCuenta() {
		return cuenta;
	}

	/**
	 * Sets the cuenta. Segundo ejemplo de "setter"
	 *
	 * @param cuenta the new cuenta
	 */
	private void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * Gets the saldo.	Tercer ejemplo de "getter"
	 *
	 * @return the saldo
	 */
	private double getSaldo() {
		return saldo;
	}

	/**
	 * Sets the saldo.	Tercer ejemplo de "setter"
	 *
	 * @param saldo the new saldo
	 */
	private void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * Gets the tipo interés.	Cuarto ejemplo de "getter"
	 *
	 * @return the tipo interés
	 */
	private double getTipoInterés() {
		return tipoInterés;
	}

	/**
	 * Sets the tipo interés.	Cuarto ejemplo de "setter"
	 *
	 * @param tipoInterés the new tipo interés
	 */
	private void setTipoInterés(double tipoInterés) {
		this.tipoInterés = tipoInterés;
	}
}
