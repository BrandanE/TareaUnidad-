/*
 * 
 */
package Cuentas;
// TODO: Auto-generated Javadoc

/**
 * La clase Main.
 */
public class Main {

    /**
     * El main method. El metodo de la clase en definitiva.
     *	
     *		
     * @param args the arguments
     */
    public static void main(String[] args) {
        CCuenta cuenta1;
        double saldoActual;

        cuenta1 = operativa_cuenta();

        try {
            cuenta1.retirar(2300);
        } catch (Exception e) {
            System.out.print("Fallo al retirar");
        }
        try {
            System.out.println("Ingreso en cuenta");
            cuenta1.ingresar(695);
        } catch (Exception e) {
            System.out.print("Fallo al ingresar");
        }
    }

	/**
	 * Operativa cuenta. El metodo que he creado. Por cierto; mejoré la salida al añadir un espacio 
	 *							para que no estuviesen pegados el texto final y el saldo.
	 *						Dejandolo así: "El saldo actual es "+ saldoActual
	 *
	 *	Pusé mi propio nombre como cambio de Parametro
	 *
	 * @return the c cuenta
	 */
	private static CCuenta operativa_cuenta() {
		CCuenta cuenta1;
		double saldoActual;
		cuenta1 = new CCuenta("Brandán Huete","1000-2365-85-1230456789",4000,0);
        saldoActual = cuenta1.estado();
        System.out.println("El saldo actual es "+ saldoActual );
		return cuenta1;
	}
} 